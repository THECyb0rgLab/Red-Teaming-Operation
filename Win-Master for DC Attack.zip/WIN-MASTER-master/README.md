# WIN-MASTER
## A PYTHON SCRIPT FILE TO REMOTELY ANALYSE AND EXPLOIT MICROSOFT WINDOWS SYSTEMS VIA IMPACKET.

Usage: python3 WinMaster.py

| LANGUAGE  | FILENAME         | MD5 Hash                         | Version    |
|------     |------            | -------                          | ----       |
| python3   | WinMaster.py     | e452f0d21198bb328b648d163aaa698d | Blackfield |

- [x] Requires Impacket (https://github.com/SecureAuthCorp/impacket) to be installed.
- [x] Requires Evil-WinRm (https://github.com/Hackplayers/evil-winrm) to be installed.
- [x] Requires Kerbrute (https://github.com/TarlogicSecurity/kerbrute) to be installed in the /usr/share/doc/python3-impacket/examples/ directory.
- [x] Requires Windapsearch (https://github.com/ropnop/windapsearch) to be installed in the /usr/share/doc/python3-impacket/examples/ directory.

**OPTIONAL**

        AclPwn (https://pypi.org/project/aclpwn/) requires BloodHound (https://github.com/BloodHoundAD/BloodHound)
        and Neo4j (https://github.com/neo4j) to be installed.
              
A python script file to remotely exploit Microsoft Windows systems- It can pull domains, usernames, passwords, crack hashes, and much much more.

### CONSOLE DISPLAY AND VIDEO LINK
[![WinMaster](https://github.com/BroadbentT/WIN-MASTER/blob/master/picture1.png)](https://youtu.be/5wBMgItFVt4 "WinMaster")

Found this project useful, or would like to see it amended in some way - make a donation.
https://paypal.me/TerenceBroadbent
