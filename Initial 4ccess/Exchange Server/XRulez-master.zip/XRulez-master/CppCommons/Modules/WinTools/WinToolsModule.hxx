#if defined(USE_MODULE_WINTOOLS) && (USE_MODULE_WINTOOLS == USE_MODULE_AS_PRECOMPILED_SOURCES OR USE_MODULE_WINTOOLS == USE_MODULE_FULL_SOURCES)
#	include "WinToolsModule.cpp"
#	include "Services.cpp"
#	include "Registry.cpp"
#endif
