# Security Policy

## Reporting a Vulnerability

Thank you for taking the time to find and report a security vulnerability in Gophish!

I'd ask that you please send me an email with the details at hi@getgophish.com rather than posting any details in the public issue tracker.

I'll happily work with you to get the vulnerability resolved as quickly as possible, and will be sure to credit you (if you'd like!) in the release notes for the following release.
