Please provide the following details.

### Host System

- OS : 
- Python version (`python --version`) : 

### Error Description

Please provide the details of the error. Try to provide the **output** and also **steps to reproduce** (if possible).

If you cloned Datasploit, also provide the output of `git log -n 1 --pretty=format:"%B"`.
