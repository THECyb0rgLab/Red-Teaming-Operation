Well, lets accept the fact that nothing goes well without contributors. Here is the list of people who have helped  ([@datasploit](https://twitter.com/datasploit)) grow in its first phase. 

##### Core Contributors:
Folks who took out time from busy schedule and got their hands dirty with the code:
* Shubham Mittal ([@upgoingstar](https://twitter.com/upgoingstar)) 
* Sudhanshu Chauhan ([@upgoingstar](https://twitter.com/sudhanshu_c))
* Kunal Aggarwal ([@KunalAggarwal92](https://twitter.com/KunalAggarwal92))
* Nutan Kumar Panda ([@nutankumarpanda](https://twitter.com/nutankumarpanda))

##### Mentors:
Chaps who were generous enough to give feedback and suggest changes:
* Anant Srivastata ([@anantshri](https://twitter.com/anantshri))
* Prashant Mahajan ([@prashant3535](https://twitter.com/prashant3535))
* Shadab Siddiqui ([@sh4ds1dd](https://twitter.com/sh4ds1dd))

##### Testers
Below people helped us by quickly adopting the tool and raised few naive issues we missed out:
* Sagar Belure ([@sagarbelure](https://twitter.com/sagarbelure))
* Chandrapal ([@bnchandrapal](https://twitter.com/bnchandrapal))